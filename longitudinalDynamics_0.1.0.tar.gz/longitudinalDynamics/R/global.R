utils::globalVariables(c("CV", "Freq", "PTID", "Sample", "Time", "UMAP_1",
                         "UMAP_2", "Var2", "createLogFile", "getArchRThreads",
                         "getGroupSE", "group", "metaData", "now", "pb",
                         "totolIter", "value", ".", "..density..", "cv_res",
                         "tSNE1", "tSNE2","ggline", "rcorr"))
